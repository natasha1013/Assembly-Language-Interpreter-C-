void DEC(const string& reg1, tableSet& myTableSet)
{
    if (reg1.length() > 1 && reg1[0] == 'R' && isdigit(reg1[1]))
    {
        int regNum1 = stoi(reg1.substr(1));
        if (regNum1 >= 0 && regNum1 <= 6)
        {
            int minusone = 1;
            // get reg1 value
            string valuefromreg1 = myTableSet.regArray[regNum1];
            // make it int
            int intvaluefromreg1 = stoi(valuefromreg1);

            //+1
            int total = intvaluefromreg1 - minusone;
            myTableSet.regArray[regNum1] = to_string(total);
        }

    }
    else
    {
        cout << reg1 << " format input is invalid." << endl;
    }
}