void mov(const string& reg1, const string& reg2, tableSet& myTableSet)
{
    //if register 2 is written in the format "R1"
    if (reg2.length() > 1 && reg2[0] == 'R' && isdigit(reg2[1]))
    {
        int regNum2 = stoi(reg2.substr(1));
        //if register 2 value is 0-6
        if (regNum2 >= 0 && regNum2 <= 6)
        {
            //(MOV 10, RO) if register 1 is a value (e.g., "20")
            if (reg1.length() > 0 && all_of(reg1.begin(), reg1.end(), ::isdigit))
            {
                int regNum1 = stoi(reg1) &0xFF;
                myTableSet.regArray[regNum2] = to_string(regNum1);
            }

            // MOV R1, RO
            else if (reg1.length() > 1 && reg1[0] == 'R' && isdigit(reg1[1]))
            {
                int regNum1 = stoi(reg1.substr(1));

                //if register 1 is a correct value (0-6)
                if (regNum1 >= 0 && regNum1 < 6)
                {
                    // get reg1 value
                    string valuefromreg1 = myTableSet.regArray[regNum1];
                    // reg1 = reg2
                    myTableSet.regArray[regNum2] = valuefromreg1;

                }
                else
                {
                    cout << "R" << reg1 << " is not in the valid range (0 - 6)." << endl;
                }
            }

            // MOV [R1], R3
            else if (reg1.length() >= 4 && reg1[0] == '[' && reg1[1] == 'R' && isdigit(reg1[2]) && reg1[3] == ']')
            {
                int regNum1 = stoi(reg1.substr(2, 1));
                //if register 1 is a correct value (0-6)
                if (regNum1 >= 0 && regNum1 < 6)
                {
                    //get reg1 value
                    string valuefromreg1 = myTableSet.regArray[regNum1];

                    //change string to int
                    int intvaluefromreg1 = stoi(valuefromreg1);
                    //get memory address of reg1
                    string memoryaddreg1 = myTableSet.memoryArray[intvaluefromreg1];

                    //store [memory address of reg1] in reg2
                    myTableSet.regArray[regNum2] = memoryaddreg1;
                }
                else
                {
                    cout << "[" << "R" << regNum1 << "]" << " is not in the valid range (0 - 6)." << endl;
                }
            }

            else
            {
                cout << reg1 << " format input is invalid." << endl;
            }
        }
    }
    else
    {
        cout << reg2 << " format input is invalid." << endl;
    }
}