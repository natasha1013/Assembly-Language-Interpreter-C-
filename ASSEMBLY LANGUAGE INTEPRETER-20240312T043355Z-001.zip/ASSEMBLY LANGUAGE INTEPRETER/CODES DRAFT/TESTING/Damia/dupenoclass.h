#ifndef TABLE_SET_H
#define TABLE_SET_H

#include <iostream>
#include <string>
#include <bitset>
#include <iomanip>
#include <algorithm>


using namespace std;
string trim(string);

void extractRegisters(const string&, string&, string&);
string trimLeft(string s);
string trimRight(string s);
string trim(string s);


#endif /* TABLE_SET_H */
