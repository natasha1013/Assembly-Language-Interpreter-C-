#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <limits>

using namespace std;

class VirtualMachine {
private:
    int registers[7]; // General-purpose registers R0-R6
    bool overflowFlag;
    bool underflowFlag;
    bool carryFlag;
    bool zeroFlag;

    bool checkOverflow(int result) {
        return (result > 127);
    }

    bool checkUnderflow(int result) {
        return (result < -128);
    }

    bool checkCarry(int result) {
        return (result > 255 || result < 0);
    }

    bool checkZero(int result) {
        return (result == 0);
    }
public:
    VirtualMachine() {
        resetFlags();
    }

    void resetFlags() {
        overflowFlag = false;
        underflowFlag = false;
        carryFlag = false;
        zeroFlag = false;
    }

    // INstruction: Read a value from the keyboard and store it into Rdst
    void IN(int Rdst) {
        cout << "Enter a number: " ;
        cin >> registers[Rdst];

        // Check for overflow, underflow, and zero
        checkFlags(registers[Rdst]);
    }

    // OUTstruction: Write to the screen the value inside the register Rsrc
    void OUT(int Rsrc) {
        cout << "Output: " << registers[Rsrc] << endl;
    }

    void checkFlags(int result)
    {
        overflowFlag = checkOverflow(result);
        underflowFlag = checkUnderflow(result);
        carryFlag = checkCarry(result);
        zeroFlag = checkZero(result);
    }


    void displayFlags() {
        cout << "Overflow Flag: " << (overflowFlag ? "true" : "false") << endl;
        cout << "Underflow Flag: " << (underflowFlag ? "true" : "false") << endl;
        cout << "Carry Flag: " << (carryFlag ? "true" : "false") << endl;
        cout << "Zero Flag: " << (zeroFlag ? "true" : "false") << endl;
    }

    void INC(int Rdst) {
        registers[Rdst]++;

        // Check for overflow and zero
        checkFlags(registers[Rdst]);
    }

    // Instruction: Decrement the value in the specified register
    void DEC(int Rdst) {
        registers[Rdst]--;

        // Check for underflow and zero
        checkFlags(registers[Rdst]);
    }
};

int main() {
    VirtualMachine vm;


    vm.IN(0);
    vm.OUT(1);
    cout << endl;
    vm.displayFlags();
    cout << endl;


    vm.IN(1);
    // Example: OUT R0
    vm.OUT(1);
    cout << endl;
    vm.displayFlags();

    vm.INC(3);
    cout << endl;
    vm.OUT(3);
    vm.displayFlags();

    vm.DEC(1);
    cout << endl;    
    vm.OUT(1);
    vm.displayFlags();


    // Display flags after IN and OUT operations

    return 0;
}
