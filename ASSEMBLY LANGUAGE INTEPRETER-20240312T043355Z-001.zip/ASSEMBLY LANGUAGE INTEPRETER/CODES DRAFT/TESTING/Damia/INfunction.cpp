void in(const string& reg1, tableSet& myTableSet)
{
    if (reg1.length() > 1 && reg1[0] == 'R' && isdigit(reg1[1]))
    {
        int regNum1 = stoi(reg1.substr(1));
        if (regNum1 >= 0 && regNum1 <= 6)
        {
            int number;
            cout << "Enter a number: " ;
            cin >> number;

            myTableSet.regArray[regNum1] = to_string(number);
        }

    }
    else
    {
        cout << reg1 << " format input is invalid." << endl;
    }
}