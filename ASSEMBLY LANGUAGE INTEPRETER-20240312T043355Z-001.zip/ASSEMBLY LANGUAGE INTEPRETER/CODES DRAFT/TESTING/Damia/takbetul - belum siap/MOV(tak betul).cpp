// MOV 10, RO
// Stores the value 10 to register
void movvaluetoreg(int regNum1, int regNum, tableSet &myTableSet) 
{
    string value = myTableSet.memoryArray[regNum1];
    myTableSet.regArray[regNum] = value;
}

// MOV R1, RO
// Copies the value stored in register R1 to RO
void movregtoreg (int regNum1, int regNum, tableSet &myTableSet)
{
    string valuereg1 = myTableSet.regArray[regNum1]; //(get value from reg1)
    myTableSet.regArray[regNum1] = myTableSet.regArray[regNum]; //(Copies the value to reg2)

}

// MOV [R1], R3
// Copies the value with the memory address stored in R1 to register R3.
void movregmemtoreg (int indexmemory, int regNum, tableSet &myTableSet)
{
    string value = myTableSet.regArray[indexmemory]; 
    
    // Convert string to integer using stoi
    int reg1value = stoi(value);

    string memoryArrayvalue = myTableSet.memoryArray[reg1value];

    myTableSet.regArray[regNum] = memoryArrayvalue; 
}



void MOV (const string& reg1, const string& reg2, tableSet& myTableSet)
{
    //if register 2 is written in the format "R1"
    if (reg2.length() > 1 && reg2[0] == 'R' && isdigit(reg2[1]))
    {
        int regNum = stoi(reg2.substr(1));

        //if register 2 value is 0-6
        if (regNum >= 0 && regNum <= 6)
        {
            //(MOV 10, RO) if register 1 is a value (e.g., "20")
            if (reg1.length() > 0 && all_of(reg1.begin(), reg1.end(), ::isdigit))
            {
                int regNum1 = stoi(reg1);
                movvaluetoreg(regNum1, regNum, myTableSet);
            }

            // MOV R1, RO
            else if (reg1.length() > 1 && reg1[0] == 'R' && isdigit(reg1[1]))
            {
                int regNum1 = stoi(reg1.substr(1));
        
                //if register 1 is a correct value (0-6)
                if (regNum1 >= 0 && regNum1 < 6) 
                {
                    movregtoreg (regNum1, regNum, myTableSet);
                }
                else 
                {
                    cout << "R" << reg1 << " is not in the valid range (0 - 6)." << endl;
                }
            }

            // MOV [R1], R3
            else if (reg1.length() >= 4 && reg1[0] == '[' && reg1[1] == 'R' && isdigit(reg1[2]) && reg1[3] == ']')
            {
                int indexmemory = stoi(reg1.substr(2, 1));
                //if register 1 is a correct value (0-6)
                if (indexmemory >= 0 && indexmemory < 6) 
                {
                    movregmemtoreg (indexmemory, regNum, myTableSet);
                }
                else
                {
                    cout << "[" << "R" << indexmemory << "]" << " is not in the valid range (0 - 6)." << endl;
                }
            }

            else
            {
                cout << reg1 << " format input is invalid." << endl;
            }
        }
    }
    else 
    {
        cout << reg2 << " format input is invalid." << endl;
    }
}



