#include "dupe.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cctype> // For isdigit
#include <cstdlib>
#include <algorithm>
#include <bitset>
#include <iomanip>

using namespace std;


string trimLeft(string s)
{
    for (int c = 0; c < s.length(); c++)
    {
        if( s[0] == ' ')
        {
            s.erase(0, 1);
        }
    }

    return s;
}

string trimRight(string s)
{
    for (int c = s.length()-1; c >= 0; c--)
    {
        if( s[s.length()-1] == ' ')
        {
            s.erase(s.length()-1, 1);
        }
    }

    return s;
}

string trim(string s)
{
    s = trimLeft(s);
    s = trimRight(s);
    return s;
}
