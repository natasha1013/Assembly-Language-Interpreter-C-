#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cctype> // For isdigit
#include <cstdlib>
#include <algorithm>
#include <bitset>
#include <iomanip>

using namespace std;

string trim(string s);
// constant the size for register and memory
const int REG_SIZE = 7;
const int MEMORY_SIZE = 64;


class tableSet
{
    public:
    bitset<4> allUnset;
    // initiate the arrays here so it is accessible
    int regSize = REG_SIZE;
    string regArray[REG_SIZE];
    int memorySize = MEMORY_SIZE;
    string memoryArray[MEMORY_SIZE];

    tableSet()
    {
        // Initialize memoryArray with default values
        fill(begin(memoryArray), end(memoryArray), allUnset.to_string());

        // Set memoryArray[20] to "44" (i letak so when start the code, ada value in memory ) *************************************************
        memoryArray[20] = "44";
    }

    void regTable(const string &reg1, const string &reg2)
    {
        for (int i = 0; i < regSize; i++)
        {
            if (regArray[i].empty())
            {
                regArray[i] = allUnset.to_string();
            }
            cout << regArray[i] << setw(6);
        }

    }

    void   flagTable()
    {
        int flagSize = 4;
        string flagArray[flagSize];

        for (int i=0; i < flagSize; i++)
        {
            if (flagArray[i].empty()){
                flagArray[i] = allUnset.to_string();
            }

            cout << flagArray[i] << setw(6);
        }

    }

    void memoryTable(const string &reg1, const string &reg2)
    {
        // Hardcode the value 44 at index 20 (this kena padam when compile, just testing if memory value will be passed to register) **********************************************************
        memoryArray[20] = "44";
        memoryArray[1] = "20";

        for (int i=0; i < memorySize; i++ )
        {
            // 0000 if the array is empty
            if (memoryArray[i].empty()){
                memoryArray[i] = allUnset.to_string();
            }

            // Convert string to integer
            int value = stoi(memoryArray[i]);

            cout << memoryArray[i];

            // Align the outputs
            if (i == 7 || i == 15 || i == 23 || i == 31 || i == 39 || i == 47 || i == 55 || i == 63) {
                cout << endl;
            } else {
                cout << setw (6);
            }
        }
    }

};

// Prototype the functions
void loadmemtoreg(int regNum, int indexmemory, tableSet& myTableSet);
void loadregmemtoreg(int regNum, int indexmemory, tableSet& myTableSet);
void storeregtomem(int regNum, int indexmemory, tableSet& myTableSet);
void storememtoreg(int regNum, int indexmemory, tableSet& myTableSet);

// Maya : Function to extract registers from the operators which are (reg1,reg2)
void extractRegisters(const string& line, string& reg1, string& reg2) {
    stringstream ss(line);
    string word;

    // Skip the first word "LOAD"
    getline(ss, word, ' ');

    // Read the first register (e.g., 20 or R1 or [R1])
    getline(ss, reg1, ',');
    reg1 = trim(reg1);

    // Read the second register (e.g., 20 or R1 or [R1])
    getline(ss, reg2, ',');
    reg2 = trim(reg2);

    // cout << "Register 1: " << reg1 << ", Register 2: " << reg2 << endl; // check whether you get the registers

}

void load(const string& reg1, const string& reg2, tableSet& myTableSet) // Used to get valid input (if incorrect it will not take the inputs)
{
    // cout << "Load operation: " << reg1 << " and " << reg2 << endl;

    // Check if register 1 is written in the format "R1"
    if (reg1.length() > 1 && reg1[0] == 'R' && isdigit(reg1[1])) {
        int regNum = stoi(reg1.substr(1));
        if (regNum >= 0 && regNum <= 6) {
            // Check if reg2 is a valid memory index (e.g., "20")
            if (reg2.length() > 0 && all_of(reg2.begin(), reg2.end(), ::isdigit)) {
                int indexmemory = stoi(reg2);
                if (indexmemory >= 0 && indexmemory < 64) {
                    // Read the value from memory and copy it to the register
                    loadmemtoreg(regNum, indexmemory, myTableSet);
                } else {
                    cout << reg2 << " is not in the valid range (0 - 64)." << endl;
                }
            } else if (reg2.length() >= 4 && reg2[0] == '[' && reg2[1] == 'R' && isdigit(reg2[2]) && reg2[3] == ']') {
                // Check if register 2 is written in the format "[R2]"
                int indexmemory = stoi(reg2.substr(2, 1));
                if (indexmemory >= 0 && indexmemory < 6) {
                    // Read the value from memory and copy it to the register
                    loadregmemtoreg(regNum, indexmemory, myTableSet);
                } else {
                    cout << "[" << "R" << indexmemory << "]" << " is not in the valid range (0 - 6)." << endl;
                }
            } else {
                cout << reg2 << " format input is invalid." << endl;
            }
        } else {
            cout << reg1 << " is not an existing register." << endl;
        }
    } else {
        cout << reg1 << " format input is invalid." << endl;
    }
}

void loadmemtoreg(int regNum, int indexmemory, tableSet &myTableSet) // For LOAD R1, 20
{
    string valueFromMemArray = myTableSet.memoryArray[indexmemory];

    myTableSet.regArray[regNum] = valueFromMemArray;
}

void loadregmemtoreg(int regNum, int indexmemory, tableSet& myTableSet) // For LOAD R1, [R2]
{
    string valueFromreg2 = myTableSet.regArray[indexmemory];
    // Convert string to integer using stoi
    int intvalueFromreg2 = stoi(valueFromreg2);

    string valueFromMemArray = myTableSet.memoryArray[intvalueFromreg2];

    myTableSet.regArray[regNum] = valueFromMemArray;
}

void store(const string& reg1, const string& reg2, tableSet& myTableSet) // Maya : I use nested if else elif so the variables (reg1,reg2) is accesable
{
    // cout << "Load operation: " << reg1 << " and " << reg2 << endl; // just for checking if it works

    // Check if reg1 is written in the format "R1"
    if (reg1.length() > 1 && reg1[0] == 'R' && isdigit(reg1[1])) {
        int regNum = stoi(reg1.substr(1)); // change the string to integer and subtract 1 from R1
        if (regNum >= 0 && regNum <= 6) {  // check if its in the range

            // Check if reg2 is a valid memory index (e.g., "20")
            if (reg2.length() > 0 && all_of(reg2.begin(), reg2.end(), ::isdigit)) {
                int indexmemory = stoi(reg2);
                if (indexmemory >= 0 && indexmemory < 64) {
                    // Read the value from memory and copy it to the register
                    storeregtomem(regNum, indexmemory, myTableSet);
                } else {
                    cout << reg2 << " is not in the valid range (0 - 64)." << endl;
                }
            } else if (reg2.length() >= 4 && reg2[0] == '[' && reg2[1] == 'R' && isdigit(reg2[2]) && reg2[3] == ']') {
                // Check if register 2 is written in the format "[R2]"
                int indexmemory = stoi(reg2.substr(2, 1));
                if (indexmemory >= 0 && indexmemory < 6) {
                    // Read the value from memory and copy it to the register
                    storememtoreg(regNum, indexmemory, myTableSet);
                } else {
                    cout << "[" << "R" << indexmemory << "]" << " is not in the valid range (0 - 6)." << endl;
                }
            } else {
                cout << reg2 << " format input is invalid." << endl;
            }
        } else {
            cout << reg1 << " is not an existing register." << endl;
        }
    } else {
        cout << reg1 << " format input is invalid." << endl;
    }
}

void storeregtomem(int regNum, int indexmemory, tableSet &myTableSet) // For STORE R1, 43
{
    string valueFromRegArray = myTableSet.regArray[regNum]; // get value from register (reg1)
    myTableSet.memoryArray[indexmemory] = valueFromRegArray; // store value into memory (reg2)
}

void storememtoreg(int regNum, int indexmemory, tableSet& myTableSet) // For STORE R1, [R2]
{
    string valueFromRegArray = myTableSet.regArray[regNum]; // get value from register (reg1)
    string valueFromReg2Array = myTableSet.regArray[indexmemory]; // get value from register (reg2)
    int intvalueFromReg2Array = stoi(valueFromReg2Array); // change the value from string to integer (it will become the memory index)
    myTableSet.memoryArray[intvalueFromReg2Array] = valueFromRegArray;
}

void show(const string &reg1, const string &reg2, tableSet &myTableSet, int pCount) // Function to print out the table
{
    cout << "Registers: ";
    myTableSet.regTable(reg1, reg2);

    // flags table
    cout << endl;
    cout << "Flags: ";
    myTableSet.flagTable();

    // PC counter
    cout << "\nPC: " << pCount + 1;

    cout << endl << endl;

    cout << "Memory: " << endl;
    myTableSet.memoryTable(reg1, reg2);

    cout << endl;
}


int main(int argc, char* argv[])
{
    // Maya : Natasha's table variable
    tableSet mem, reg, flag;
    string reg1, reg2;

    //declare an input file handler
    ifstream infile; // read from file
    ofstream outfile; // write to file

    // open file
    infile.open("fileInput1.asm");

    if( infile.fail())
    {
        cout << "Error message: file is not found" << endl;
        return EXIT_FAILURE;
    }

    // read the file line by line
    string line;
    int pCount = 0; // Maya : I letak declare pCount Natasha kat sini
    while ( getline(infile, line) ) // read like cin
    {
        stringstream ss(line);

        string word;
        // read without the comma, parsing
        bool isLineParsed = false;
        while ( getline(ss, word, ',') && !isLineParsed)
        {
            word = trim(word);
            if (word.substr(0, 3) == "MOV")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 2) == "IN")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "OUT")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "ADD")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "SUB")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "MUL")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "DIV")
            {
                cout << line << endl;
                isLineParsed = true;
            }

            else if (word.substr(0, 3) == "INC")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "DEC")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "ROL")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "ROR")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "SHL")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "SHR")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 4) == "LOAD")
            {
                cout << line << endl;
                extractRegisters(line, reg1, reg2); // go to extract register function
                load(reg1,reg2, mem);
                show(reg1, reg2, mem, pCount);
                isLineParsed = true;
            }
            else if (word.substr(0, 5) == "STORE")
            {
                cout << line << endl;
                extractRegisters(line, reg1, reg2);
                store(reg1,reg2, mem);
                show(reg1, reg2, mem, pCount);
                isLineParsed = true;
            }
            else
            {
                cout << "Error message: this line cannot be parsed: " << line << endl;
            }
        }
        // Maya : pCount++ Natasha kat sini
        pCount++;
    }

    infile.close();

    return 0;
}

string trimLeft(string s)
{
    for (int c = 0; c < s.length(); c++)
    {
        if( s[0] == ' ')
        {
            s.erase(0, 1);
        }
    }

    return s;
}

string trimRight(string s)
{
    for (int c = s.length()-1; c >= 0; c--)
    {
        if( s[s.length()-1] == ' ')
        {
            s.erase(s.length()-1, 1);
        }
    }

    return s;
}

string trim(string s)
{
    s = trimLeft(s);
    s = trimRight(s);
    return s;
}
