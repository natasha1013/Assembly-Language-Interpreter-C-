#include <iostream>
#include <bitset>
using namespace std;

int main()
{
    int num; // Maya : declare the variable

    //Maya : Ask to input a number and get the input
    cout << "Please enter a number from (-128 - 127)" << endl;
    cin >> num;

    // Maya : To check whether the number is in the range ( -128 - 127)
    while (num < -128 || num > 127)
    {
        cout << "ERROR, number input exceeds the range!" << endl;
        cout << "Please enter a number from (-128 - 127)" << endl;
        cin >> num;
    }

    num = num + 128; // Maya : I'm still not sure why have to add 128

    // Maya : Convert decimal to binary
    string bitnum = bitset<8>(num).to_string();

    cout << "Binary representation: " << bitnum << endl;

    // Maya : Perform a right shift
    bitset<8> shiftright(bitset<8>(bitnum) >> 1);

    cout << "Right-Shifted Binary representation: " << shiftright << endl;

    // Maya : Convert binary to decimal
    bitset<8> binaryBits(shiftright);
    unsigned long decnum = binaryBits.to_ulong();

    cout << "Decimal representation: " << decnum << endl;

    int result = decnum - 128; // Maya : I still don't know why have to -128

    cout << "Result after subtracting 128: " << result << endl;

    return 0;
}
