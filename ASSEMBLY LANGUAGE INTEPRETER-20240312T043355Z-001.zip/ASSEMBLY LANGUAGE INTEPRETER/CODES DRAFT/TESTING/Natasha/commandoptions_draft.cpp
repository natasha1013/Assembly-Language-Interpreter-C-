#include <bitset>
#include <iostream>
#include <iomanip>
#include <string>
#include <cctype>
using namespace std;

class tableSet
{
    public:

    void   regTable()
    {
        int regSize = 7;
        string regArray[regSize];

        for (int i=0; i < regSize; i++)
        {
            // Check if empty
            if (regArray[i].empty()){
                regArray[i] = allUnset.to_string();
            }
            cout << regArray[i] << setw(6);
        }

    }

    void   flagTable()
    {
        int flagSize = 4;
        string flagArray[flagSize];

        for (int i=0; i < flagSize; i++)
        {
            if (flagArray[i].empty()){
                flagArray[i] = allUnset.to_string();
            }

            cout << flagArray[i] << setw(6);
        }

    }

    void memoryTable()
    {
        string memoryArray[memorySize];
        for (int i=0; i < memorySize; i++ )
        {
            // 0000 if the array is empty
            if (memoryArray[i].empty()){
                memoryArray[i] = allUnset.to_string();
            }

            cout << memoryArray[i];

            // Align the outputs
            if (i == 7 || i == 15 || i == 23 || i == 31 || i == 39 || i == 47 || i == 55 || i == 63) {
                cout << endl;
            } else {
                cout << setw (6);
            }
        }
    }

    private:
    bitset<4> allUnset;
    int memorySize = 64;

};

int main(){
    tableSet mem, reg, flag;
    string command;
    int pCount = 0;

    cout << "Testing"<< endl;

    do{
            // non-sensitive inputs
            cin >> command;
            for (char &c : command) {
                c = tolower(c);
            }


            // MENUS
            if (command == "mul" || command == "div"){
                cout << "This is for multiplying or dividing" << endl;
                cout << "\nRegisters: ";
                reg.regTable();

                // flags table
                cout << endl;
                cout << "Flags: ";
                flag.flagTable();

                // PC counter
                cout << "\nPC: " << pCount + 1;

                cout << endl << endl;

                cout << "Memory: " << endl;
                mem.memoryTable();

                cout << endl;
                pCount++;

            } else if (command == "#"){
                break;

            } else {
                cout << "ERROR: Please try again" << endl;
            }

    } while (command != "#");

    return 0;
}
