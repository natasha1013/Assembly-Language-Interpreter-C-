#include <cctype>
#include <iostream>
#include <iomanip>
using namespace std;

void multiply()
{
    cout << "Hello World!" << endl;
}

int main()
{
    string command, num1, num2;
    cin >> command, num1, num2;

    for (char &c : command)
    {
        c = tolower(c);
    }

    if (command == "mul")
    {
        multiply();
    }


    return 0;
}
