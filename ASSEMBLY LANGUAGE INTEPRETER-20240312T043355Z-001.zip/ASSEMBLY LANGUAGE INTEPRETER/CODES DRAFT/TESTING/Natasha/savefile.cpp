// prototype
void saveFile(const string&, const string&, tableSet&, int);

// in main: before infile.close()
saveFile(reg1, reg2, mem, pCount);


void saveFile(const string &reg1, const string &reg2, tableSet &myTableSet, int pCount){
    ofstream outputFile("Output.txt");

    if (outputFile.is_open()){
        outputFile << "Registers: ";
        for (int i = 0; i < myTableSet.regSize; i++) {
            if (myTableSet.regArray[i].empty()) {
                myTableSet.regArray[i] = myTableSet.allUnset.to_string();
            }
            outputFile << " " << myTableSet.regArray[i];
        }
        outputFile << "#" << endl;

        outputFile << "Flags: ";
        for (int i = 0; i < myTableSet.flagSize; i++) {
            if (myTableSet.flagArray[i].empty()) {
                myTableSet.flagArray[i] = "0";
            }

            outputFile << " " << myTableSet.flagArray[i];
            myTableSet.flagArray[i] = "0";
        }
        outputFile << "#" << endl;

        outputFile << "PC: " << pCount << endl; // Print PC to the file

        outputFile << "Memory: " << endl;
        for (int i = 0; i < myTableSet.memorySize; i++) {
            if (myTableSet.memoryArray[i].empty()) {
                myTableSet.memoryArray[i] = myTableSet.allUnset.to_string();
            }

            int value = stoi(myTableSet.memoryArray[i]);
            outputFile << myTableSet.memoryArray[i];

            if (i == 7 || i == 15 || i == 23 || i == 31 || i == 39 || i == 47 || i == 55 || i == 63) {
                outputFile << endl;
            } else {
                outputFile << setw(6);
            }
        }
        outputFile << "#" << endl;

        outputFile.close();
    }
}
