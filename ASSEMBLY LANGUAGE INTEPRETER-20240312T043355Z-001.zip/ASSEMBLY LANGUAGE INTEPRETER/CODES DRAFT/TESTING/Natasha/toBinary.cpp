// prototype
void toBinary(int, int, tableSet& myTableSet);

// function, remove 0xFF and remove the save option after that
void toBinary(int result, int regNum, tableSet& myTableSet){

    string value;

    while(result < 0){
        result = result + 256;
    }

    unsigned char c = static_cast<char>(result);

    for (int i = 7; i >= 0; --i) {
        value += ((c >> i) & 1) + '0';
    }

    cout << result;

    int decimal = 0;
    int size = value.size();

    for (int i = 0; i < size; ++i) {
        if (value[i] == '1') {
            decimal += pow(2, size - 1 - i);
        }
    }

    myTableSet.regArray[regNum] = to_string(decimal);
}
