#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

string trim(string s);

int main(int argc, char* argv[])
{
    //declare an input file handler
    ifstream infile; // read from file
    ofstream outfile; // write to file

    // open file
    infile.open("fileInput1.asm");

    if( infile.fail())
    {
        cout << "Error message: file is not found" << endl;
        return EXIT_FAILURE;
    }

    // read the file line by line
    string line;
    while ( getline(infile, line) ) // read like cin
    {
        stringstream ss(line);

        string word;
        // read without the comma, parsing
        bool isLineParsed = false;
        while ( getline(ss, word, ',') && !isLineParsed)
        {
            word = trim(word);
            if (word.substr(0, 3) == "MOV")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 2) == "IN")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "OUT")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "ADD")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "SUB")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "MUL")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "DIV")
            {
                cout << line << endl;
                isLineParsed = true;
            }

            else if (word.substr(0, 3) == "INC")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "DEC")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "ROL")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "ROR")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "SHL")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 3) == "SHR")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 4) == "LOAD")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else if (word.substr(0, 5) == "STORE")
            {
                cout << line << endl;
                isLineParsed = true;
            }
            else
            {
                cout << "Error message: this line cannot be parsed: " << line << endl;
            }
        }
    }

    infile.close();

    return 0;
}

string trimLeft(string s)
{
    for (int c = 0; c < s.length(); c++)
    {
        if( s[0] == ' ')
        {
            s.erase(0, 1);
        }
    }

    return s;
}

string trimRight(string s)
{
    for (int c = s.length()-1; c >= 0; c--)
    {
        if( s[s.length()-1] == ' ')
        {
            s.erase(s.length()-1, 1);
        }
    }

    return s;
}

string trim(string s)
{
    s = trimLeft(s);
    s = trimRight(s);
    return s;
}
